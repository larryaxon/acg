﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace ACG.App.Common
{
  public class ACGExceptionMessage : ACG.Common.ExceptionMessage
  {

  }
}
