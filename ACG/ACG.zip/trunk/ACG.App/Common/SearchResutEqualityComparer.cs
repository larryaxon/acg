﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ACG.App.Common
{
  [Serializable]
  public class SearchResutEqualityComparer : ACG.Common.SearchResutEqualityComparer
  {

  }
}
