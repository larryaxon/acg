﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace ACG.App.Common
{
  [Serializable]
  public class SearchResult : ACG.Common.SearchResult
  {
    public string Address = string.Empty;
    public string City = string.Empty;
    public string State = string.Empty;
    public string Zip = string.Empty;
  }
}
