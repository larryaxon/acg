﻿namespace ACG.CommonForms
{
  partial class ctlSearch
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.ckIncludeTermed = new System.Windows.Forms.CheckBox();
      this.lstSearchList = new System.Windows.Forms.ListBox();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.btnExpand = new System.Windows.Forms.Button();
      this.ckNew = new System.Windows.Forms.CheckBox();
      this.SuspendLayout();
      // 
      // ckIncludeTermed
      // 
      this.ckIncludeTermed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.ckIncludeTermed.AutoSize = true;
      this.ckIncludeTermed.Location = new System.Drawing.Point(139, 1);
      this.ckIncludeTermed.Name = "ckIncludeTermed";
      this.ckIncludeTermed.Size = new System.Drawing.Size(94, 17);
      this.ckIncludeTermed.TabIndex = 8;
      this.ckIncludeTermed.Text = "Show Inactive";
      this.ckIncludeTermed.UseVisualStyleBackColor = true;
      // 
      // lstSearchList
      // 
      this.lstSearchList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.lstSearchList.FormattingEnabled = true;
      this.lstSearchList.Location = new System.Drawing.Point(3, 24);
      this.lstSearchList.Name = "lstSearchList";
      this.lstSearchList.Size = new System.Drawing.Size(297, 199);
      this.lstSearchList.TabIndex = 7;
      this.lstSearchList.Tag = "Master";
      this.lstSearchList.Visible = false;
      this.lstSearchList.DoubleClick += new System.EventHandler(this.lstSearchList_DoubleClick);
      this.lstSearchList.Enter += new System.EventHandler(this.lstSearchList_Enter);
      this.lstSearchList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lstSearchList_KeyUp);
      this.lstSearchList.Leave += new System.EventHandler(this.lstSearchList_Leave);
      // 
      // txtSearch
      // 
      this.txtSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtSearch.Location = new System.Drawing.Point(3, 1);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(130, 20);
      this.txtSearch.TabIndex = 6;
      this.txtSearch.Tag = "Master";
      this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
      this.txtSearch.Enter += new System.EventHandler(this.txtSearch_Enter);
      this.txtSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyUp);
      this.txtSearch.Leave += new System.EventHandler(this.txtSearch_Leave);
      // 
      // btnExpand
      // 
      this.btnExpand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnExpand.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnExpand.Location = new System.Drawing.Point(280, 1);
      this.btnExpand.Name = "btnExpand";
      this.btnExpand.Size = new System.Drawing.Size(17, 17);
      this.btnExpand.TabIndex = 9;
      this.btnExpand.Text = "...";
      this.btnExpand.UseVisualStyleBackColor = true;
      this.btnExpand.Click += new System.EventHandler(this.btnExpand_Click);
      // 
      // ckNew
      // 
      this.ckNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.ckNew.AutoSize = true;
      this.ckNew.Location = new System.Drawing.Point(229, 1);
      this.ckNew.Name = "ckNew";
      this.ckNew.Size = new System.Drawing.Size(48, 17);
      this.ckNew.TabIndex = 10;
      this.ckNew.Text = "New";
      this.ckNew.UseVisualStyleBackColor = true;
      // 
      // ctlSearch
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.Controls.Add(this.ckNew);
      this.Controls.Add(this.btnExpand);
      this.Controls.Add(this.ckIncludeTermed);
      this.Controls.Add(this.lstSearchList);
      this.Controls.Add(this.txtSearch);
      this.Name = "ctlSearch";
      this.Size = new System.Drawing.Size(303, 222);
      this.Enter += new System.EventHandler(this.ctlSearch_Enter);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.CheckBox ckIncludeTermed;
    private System.Windows.Forms.ListBox lstSearchList;
    private System.Windows.Forms.TextBox txtSearch;
    private System.Windows.Forms.Button btnExpand;
    private System.Windows.Forms.CheckBox ckNew;
  }
}
