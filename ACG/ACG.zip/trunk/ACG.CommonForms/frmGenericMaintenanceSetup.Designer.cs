﻿namespace ACG.CommonForms
{
  partial class frmGenericMaintenanceSetup
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.label1 = new System.Windows.Forms.Label();
      this.txtSearchDataSource = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.btnTestSearch = new System.Windows.Forms.Button();
      this.btnDelete = new System.Windows.Forms.Button();
      this.btnSave = new System.Windows.Forms.Button();
      this.btnNew = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.label4 = new System.Windows.Forms.Label();
      this.btnTestGrid = new System.Windows.Forms.Button();
      this.btnTest = new System.Windows.Forms.Button();
      this.label5 = new System.Windows.Forms.Label();
      this.txtIndexFields = new System.Windows.Forms.TextBox();
      this.txtHiddenFields = new System.Windows.Forms.TextBox();
      this.label6 = new System.Windows.Forms.Label();
      this.txtReadonlyFields = new System.Windows.Forms.TextBox();
      this.label7 = new System.Windows.Forms.Label();
      this.ckCanAdd = new System.Windows.Forms.CheckBox();
      this.ckCanEdit = new System.Windows.Forms.CheckBox();
      this.ckCanDelete = new System.Windows.Forms.CheckBox();
      this.label8 = new System.Windows.Forms.Label();
      this.txtLastModifiedBy = new System.Windows.Forms.TextBox();
      this.txtLastModifiedDateTime = new System.Windows.Forms.TextBox();
      this.label9 = new System.Windows.Forms.Label();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.lblTestProgress = new System.Windows.Forms.Label();
      this.lblTestSearch = new System.Windows.Forms.Label();
      this.btnCancelTestSearch = new System.Windows.Forms.Button();
      this.srchTest = new ACG.CommonForms.ctlSearch();
      this.ctlTestGrid = new ACG.CommonForms.ctlSearchGrid();
      this.srchScreenName = new ACG.CommonForms.ctlSearch();
      this.srchTableName = new ACG.CommonForms.ctlSearch();
      this.srchGridDataSource = new ACG.CommonForms.ctlSearch();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(19, 23);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(41, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Screen";
      // 
      // txtSearchDataSource
      // 
      this.txtSearchDataSource.Location = new System.Drawing.Point(136, 65);
      this.txtSearchDataSource.Name = "txtSearchDataSource";
      this.txtSearchDataSource.Size = new System.Drawing.Size(344, 20);
      this.txtSearchDataSource.TabIndex = 2;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(19, 73);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(104, 13);
      this.label2.TabIndex = 3;
      this.label2.Text = "Search Data Source";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(19, 95);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(34, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Table";
      // 
      // btnTestSearch
      // 
      this.btnTestSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnTestSearch.Location = new System.Drawing.Point(850, 10);
      this.btnTestSearch.Name = "btnTestSearch";
      this.btnTestSearch.Size = new System.Drawing.Size(75, 23);
      this.btnTestSearch.TabIndex = 17;
      this.btnTestSearch.Text = "Test Search";
      this.btnTestSearch.UseVisualStyleBackColor = true;
      this.btnTestSearch.Click += new System.EventHandler(this.btnTestSearch_Click);
      // 
      // btnDelete
      // 
      this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnDelete.Location = new System.Drawing.Point(690, 10);
      this.btnDelete.Name = "btnDelete";
      this.btnDelete.Size = new System.Drawing.Size(75, 23);
      this.btnDelete.TabIndex = 15;
      this.btnDelete.Text = "Delete";
      this.btnDelete.UseVisualStyleBackColor = true;
      this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
      // 
      // btnSave
      // 
      this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnSave.Location = new System.Drawing.Point(770, 10);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new System.Drawing.Size(75, 23);
      this.btnSave.TabIndex = 16;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
      // 
      // btnNew
      // 
      this.btnNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnNew.Location = new System.Drawing.Point(610, 10);
      this.btnNew.Name = "btnNew";
      this.btnNew.Size = new System.Drawing.Size(75, 23);
      this.btnNew.TabIndex = 14;
      this.btnNew.Text = "New";
      this.btnNew.UseVisualStyleBackColor = true;
      this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnCancel.Location = new System.Drawing.Point(530, 10);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(75, 23);
      this.btnCancel.TabIndex = 13;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.UseVisualStyleBackColor = true;
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(19, 117);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(89, 13);
      this.label4.TabIndex = 20;
      this.label4.Text = "Grid Data Source";
      // 
      // btnTestGrid
      // 
      this.btnTestGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnTestGrid.Location = new System.Drawing.Point(930, 10);
      this.btnTestGrid.Name = "btnTestGrid";
      this.btnTestGrid.Size = new System.Drawing.Size(75, 23);
      this.btnTestGrid.TabIndex = 18;
      this.btnTestGrid.Text = "Test Grid";
      this.btnTestGrid.UseVisualStyleBackColor = true;
      this.btnTestGrid.Click += new System.EventHandler(this.btnTestGrid_Click);
      // 
      // btnTest
      // 
      this.btnTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnTest.Location = new System.Drawing.Point(1010, 10);
      this.btnTest.Name = "btnTest";
      this.btnTest.Size = new System.Drawing.Size(75, 23);
      this.btnTest.TabIndex = 19;
      this.btnTest.Text = "Test Screen";
      this.btnTest.UseVisualStyleBackColor = true;
      this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(19, 139);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(63, 13);
      this.label5.TabIndex = 23;
      this.label5.Text = "Index Fields";
      // 
      // txtIndexFields
      // 
      this.txtIndexFields.Location = new System.Drawing.Point(136, 137);
      this.txtIndexFields.Name = "txtIndexFields";
      this.txtIndexFields.Size = new System.Drawing.Size(344, 20);
      this.txtIndexFields.TabIndex = 5;
      // 
      // txtHiddenFields
      // 
      this.txtHiddenFields.Location = new System.Drawing.Point(136, 158);
      this.txtHiddenFields.Name = "txtHiddenFields";
      this.txtHiddenFields.Size = new System.Drawing.Size(344, 20);
      this.txtHiddenFields.TabIndex = 6;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(19, 161);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(71, 13);
      this.label6.TabIndex = 25;
      this.label6.Text = "Hidden Fields";
      // 
      // txtReadonlyFields
      // 
      this.txtReadonlyFields.Location = new System.Drawing.Point(136, 179);
      this.txtReadonlyFields.Name = "txtReadonlyFields";
      this.txtReadonlyFields.Size = new System.Drawing.Size(344, 20);
      this.txtReadonlyFields.TabIndex = 7;
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(19, 183);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(82, 13);
      this.label7.TabIndex = 27;
      this.label7.Text = "Readonly Fields";
      // 
      // ckCanAdd
      // 
      this.ckCanAdd.AutoSize = true;
      this.ckCanAdd.Location = new System.Drawing.Point(136, 207);
      this.ckCanAdd.Name = "ckCanAdd";
      this.ckCanAdd.Size = new System.Drawing.Size(135, 17);
      this.ckCanAdd.TabIndex = 8;
      this.ckCanAdd.Text = "Can Add New Records";
      this.ckCanAdd.UseVisualStyleBackColor = true;
      // 
      // ckCanEdit
      // 
      this.ckCanEdit.AutoSize = true;
      this.ckCanEdit.Location = new System.Drawing.Point(275, 207);
      this.ckCanEdit.Name = "ckCanEdit";
      this.ckCanEdit.Size = new System.Drawing.Size(109, 17);
      this.ckCanEdit.TabIndex = 9;
      this.ckCanEdit.Text = "Can Edit Records";
      this.ckCanEdit.UseVisualStyleBackColor = true;
      // 
      // ckCanDelete
      // 
      this.ckCanDelete.AutoSize = true;
      this.ckCanDelete.Location = new System.Drawing.Point(388, 207);
      this.ckCanDelete.Name = "ckCanDelete";
      this.ckCanDelete.Size = new System.Drawing.Size(122, 17);
      this.ckCanDelete.TabIndex = 10;
      this.ckCanDelete.Text = "Can Delete Records";
      this.ckCanDelete.UseVisualStyleBackColor = true;
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(19, 229);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(85, 13);
      this.label8.TabIndex = 32;
      this.label8.Text = "Last Modified By";
      // 
      // txtLastModifiedBy
      // 
      this.txtLastModifiedBy.Enabled = false;
      this.txtLastModifiedBy.Location = new System.Drawing.Point(133, 226);
      this.txtLastModifiedBy.Name = "txtLastModifiedBy";
      this.txtLastModifiedBy.Size = new System.Drawing.Size(121, 20);
      this.txtLastModifiedBy.TabIndex = 11;
      // 
      // txtLastModifiedDateTime
      // 
      this.txtLastModifiedDateTime.Enabled = false;
      this.txtLastModifiedDateTime.Location = new System.Drawing.Point(263, 226);
      this.txtLastModifiedDateTime.Name = "txtLastModifiedDateTime";
      this.txtLastModifiedDateTime.Size = new System.Drawing.Size(217, 20);
      this.txtLastModifiedDateTime.TabIndex = 12;
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(19, 47);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(60, 13);
      this.label9.TabIndex = 36;
      this.label9.Text = "Description";
      // 
      // txtDescription
      // 
      this.txtDescription.Location = new System.Drawing.Point(136, 44);
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(344, 20);
      this.txtDescription.TabIndex = 1;
      // 
      // lblTestProgress
      // 
      this.lblTestProgress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.lblTestProgress.AutoSize = true;
      this.lblTestProgress.ForeColor = System.Drawing.Color.Red;
      this.lblTestProgress.Location = new System.Drawing.Point(497, 229);
      this.lblTestProgress.Name = "lblTestProgress";
      this.lblTestProgress.Size = new System.Drawing.Size(0, 13);
      this.lblTestProgress.TabIndex = 38;
      this.lblTestProgress.Visible = false;
      // 
      // lblTestSearch
      // 
      this.lblTestSearch.AutoSize = true;
      this.lblTestSearch.Location = new System.Drawing.Point(527, 47);
      this.lblTestSearch.Name = "lblTestSearch";
      this.lblTestSearch.Size = new System.Drawing.Size(65, 13);
      this.lblTestSearch.TabIndex = 40;
      this.lblTestSearch.Text = "Test Search";
      this.lblTestSearch.Visible = false;
      // 
      // btnCancelTestSearch
      // 
      this.btnCancelTestSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btnCancelTestSearch.Location = new System.Drawing.Point(1010, 37);
      this.btnCancelTestSearch.Name = "btnCancelTestSearch";
      this.btnCancelTestSearch.Size = new System.Drawing.Size(75, 23);
      this.btnCancelTestSearch.TabIndex = 41;
      this.btnCancelTestSearch.Text = "Cancel Test";
      this.btnCancelTestSearch.UseVisualStyleBackColor = true;
      this.btnCancelTestSearch.Visible = false;
      this.btnCancelTestSearch.Click += new System.EventHandler(this.btnCancelTestSearch_Click);
      // 
      // srchTest
      // 
      this.srchTest.AddNewMode = false;
      this.srchTest.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.srchTest.AutoAddNewMode = false;
      this.srchTest.AutoSelectWhenMatch = false;
      this.srchTest.AutoTabToNextControlOnSelect = true;
      this.srchTest.ClearSearchWhenComplete = false;
      this.srchTest.Collapsed = true;
      this.srchTest.CreatedNewItem = false;
      this.srchTest.DisplayOnlyDescription = false;
      this.srchTest.DisplayOnlyID = true;
      this.srchTest.FixKeySpace = "-1";
      this.srchTest.ID = "";
      this.srchTest.Location = new System.Drawing.Point(610, 40);
      this.srchTest.MaxHeight = 228;
      this.srchTest.MustExistInList = false;
      this.srchTest.MustExistMessage = "You must enter a valid value";
      this.srchTest.Name = "srchTest";
      this.srchTest.SearchExec = null;
      this.srchTest.ShowCustomerNameWhenSet = true;
      this.srchTest.ShowTermedCheckBox = false;
      this.srchTest.Size = new System.Drawing.Size(395, 24);
      this.srchTest.TabIndex = 39;
      this.srchTest.Visible = false;
      // 
      // ctlTestGrid
      // 
      this.ctlTestGrid.AllowSortByColumn = true;
      this.ctlTestGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.ctlTestGrid.AutoRefreshWhenFieldChecked = false;
      this.ctlTestGrid.CanChangeDisplayFields = true;
      this.ctlTestGrid.CanChangeDisplaySearchCriteria = true;
      this.ctlTestGrid.ColumnName = "";
      this.ctlTestGrid.DisplayFields = false;
      this.ctlTestGrid.DisplaySearchCriteria = true;
      this.ctlTestGrid.FieldsDefaultIsChecked = true;
      this.ctlTestGrid.ForceReloadSearchColumns = false;
      this.ctlTestGrid.IDList = null;
      this.ctlTestGrid.IncludeGroupAsCriteria = false;
      this.ctlTestGrid.InnerWhere = "";
      this.ctlTestGrid.Location = new System.Drawing.Point(4, 252);
      this.ctlTestGrid.Name = "ctlTestGrid";
      this.ctlTestGrid.NameType = null;
      this.ctlTestGrid.SearchCriteria = null;
      this.ctlTestGrid.Size = new System.Drawing.Size(1090, 225);
      this.ctlTestGrid.TabIndex = 37;
      this.ctlTestGrid.Title = "Search (0 Records Found)";
      this.ctlTestGrid.UniqueIdentifier = "ID";
      this.ctlTestGrid.UseNamedSearches = false;
      // 
      // srchScreenName
      // 
      this.srchScreenName.AddNewMode = false;
      this.srchScreenName.AutoAddNewMode = true;
      this.srchScreenName.AutoSelectWhenMatch = false;
      this.srchScreenName.AutoTabToNextControlOnSelect = true;
      this.srchScreenName.ClearSearchWhenComplete = false;
      this.srchScreenName.Collapsed = true;
      this.srchScreenName.CreatedNewItem = false;
      this.srchScreenName.DisplayOnlyDescription = false;
      this.srchScreenName.DisplayOnlyID = false;
      this.srchScreenName.FixKeySpace = "-1";
      this.srchScreenName.ID = "";
      this.srchScreenName.Location = new System.Drawing.Point(133, 19);
      this.srchScreenName.MaxHeight = 228;
      this.srchScreenName.MustExistInList = false;
      this.srchScreenName.MustExistMessage = "You must enter a valid table";
      this.srchScreenName.Name = "srchScreenName";
      this.srchScreenName.SearchExec = null;
      this.srchScreenName.ShowCustomerNameWhenSet = true;
      this.srchScreenName.ShowTermedCheckBox = false;
      this.srchScreenName.Size = new System.Drawing.Size(351, 24);
      this.srchScreenName.TabIndex = 0;
      this.srchScreenName.OnSelected += new System.EventHandler<System.EventArgs>(this.srchDataSource_OnSelected);
      // 
      // srchTableName
      // 
      this.srchTableName.AddNewMode = false;
      this.srchTableName.AutoAddNewMode = false;
      this.srchTableName.AutoSelectWhenMatch = false;
      this.srchTableName.AutoTabToNextControlOnSelect = true;
      this.srchTableName.ClearSearchWhenComplete = false;
      this.srchTableName.Collapsed = true;
      this.srchTableName.CreatedNewItem = false;
      this.srchTableName.DisplayOnlyDescription = false;
      this.srchTableName.DisplayOnlyID = true;
      this.srchTableName.FixKeySpace = "-1";
      this.srchTableName.ID = "";
      this.srchTableName.Location = new System.Drawing.Point(133, 86);
      this.srchTableName.MaxHeight = 228;
      this.srchTableName.MustExistInList = false;
      this.srchTableName.MustExistMessage = "You must enter a valid value";
      this.srchTableName.Name = "srchTableName";
      this.srchTableName.SearchExec = null;
      this.srchTableName.ShowCustomerNameWhenSet = true;
      this.srchTableName.ShowTermedCheckBox = false;
      this.srchTableName.Size = new System.Drawing.Size(351, 24);
      this.srchTableName.TabIndex = 3;
      // 
      // srchGridDataSource
      // 
      this.srchGridDataSource.AddNewMode = false;
      this.srchGridDataSource.AutoAddNewMode = false;
      this.srchGridDataSource.AutoSelectWhenMatch = false;
      this.srchGridDataSource.AutoTabToNextControlOnSelect = true;
      this.srchGridDataSource.ClearSearchWhenComplete = false;
      this.srchGridDataSource.Collapsed = true;
      this.srchGridDataSource.CreatedNewItem = false;
      this.srchGridDataSource.DisplayOnlyDescription = false;
      this.srchGridDataSource.DisplayOnlyID = false;
      this.srchGridDataSource.FixKeySpace = "-1";
      this.srchGridDataSource.ID = "";
      this.srchGridDataSource.Location = new System.Drawing.Point(133, 111);
      this.srchGridDataSource.MaxHeight = 228;
      this.srchGridDataSource.MustExistInList = true;
      this.srchGridDataSource.MustExistMessage = "You must enter a valid grid data source";
      this.srchGridDataSource.Name = "srchGridDataSource";
      this.srchGridDataSource.SearchExec = null;
      this.srchGridDataSource.ShowCustomerNameWhenSet = true;
      this.srchGridDataSource.ShowTermedCheckBox = false;
      this.srchGridDataSource.Size = new System.Drawing.Size(351, 25);
      this.srchGridDataSource.TabIndex = 4;
      // 
      // frmGenericMaintenanceSetup
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1098, 482);
      this.Controls.Add(this.srchScreenName);
      this.Controls.Add(this.srchTableName);
      this.Controls.Add(this.srchGridDataSource);
      this.Controls.Add(this.btnCancelTestSearch);
      this.Controls.Add(this.lblTestSearch);
      this.Controls.Add(this.srchTest);
      this.Controls.Add(this.lblTestProgress);
      this.Controls.Add(this.ctlTestGrid);
      this.Controls.Add(this.label9);
      this.Controls.Add(this.txtDescription);
      this.Controls.Add(this.txtLastModifiedDateTime);
      this.Controls.Add(this.txtLastModifiedBy);
      this.Controls.Add(this.label8);
      this.Controls.Add(this.ckCanDelete);
      this.Controls.Add(this.ckCanEdit);
      this.Controls.Add(this.ckCanAdd);
      this.Controls.Add(this.txtReadonlyFields);
      this.Controls.Add(this.label7);
      this.Controls.Add(this.txtHiddenFields);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.txtIndexFields);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.btnTest);
      this.Controls.Add(this.btnTestGrid);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.btnTestSearch);
      this.Controls.Add(this.btnDelete);
      this.Controls.Add(this.btnSave);
      this.Controls.Add(this.btnNew);
      this.Controls.Add(this.btnCancel);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.txtSearchDataSource);
      this.Controls.Add(this.label1);
      this.Name = "frmGenericMaintenanceSetup";
      this.Text = "frmGenericMaintenanceSetup";
      this.Load += new System.EventHandler(this.frmGenericMaintenanceSetup_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private ctlSearch srchScreenName;
    private System.Windows.Forms.TextBox txtSearchDataSource;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Button btnTestSearch;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.Button btnSave;
    private System.Windows.Forms.Button btnNew;
    private System.Windows.Forms.Button btnCancel;
    private ctlSearch srchTableName;
    private ctlSearch srchGridDataSource;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Button btnTestGrid;
    private System.Windows.Forms.Button btnTest;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.TextBox txtIndexFields;
    private System.Windows.Forms.TextBox txtHiddenFields;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.TextBox txtReadonlyFields;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.CheckBox ckCanAdd;
    private System.Windows.Forms.CheckBox ckCanEdit;
    private System.Windows.Forms.CheckBox ckCanDelete;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.TextBox txtLastModifiedBy;
    private System.Windows.Forms.TextBox txtLastModifiedDateTime;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.TextBox txtDescription;
    private ctlSearchGrid ctlTestGrid;
    private System.Windows.Forms.Label lblTestProgress;
    private ctlSearch srchTest;
    private System.Windows.Forms.Label lblTestSearch;
    private System.Windows.Forms.Button btnCancelTestSearch;
  }
}