﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TAGBOSS.Common
{
  public enum ExpressionType { Function, Attribute, Literal, Condition, List, AtAtValue, Operator } ;
}
