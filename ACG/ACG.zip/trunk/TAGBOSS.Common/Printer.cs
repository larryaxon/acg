﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;


namespace TAGBOSS.Common
{
  public class Printer
  {
    public static void PrintPdf(string fileName)
    {
      //Process process = new Process();
      //process.StartInfo.Verb = "print";
      //process.StartInfo.Verb
      //With New Process 
      //      .StartInfo.Verb = "print" 
      //      .StartInfo.CreateNoWindow = False 
      //      .StartInfo.FileName = "C:\test.pdf" 
      //      .Start() 
      //      .WaitForExit(10000) 
      //      .CloseMainWindow() 
      //      .Close() 
      //  End With 
    }
  }
}
