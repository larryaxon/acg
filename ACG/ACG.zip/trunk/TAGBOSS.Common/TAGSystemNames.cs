﻿using System;
using System.Text;

namespace TAGBOSS.Common
{
  public enum TAGSystemNames { V3, V4 }
}
