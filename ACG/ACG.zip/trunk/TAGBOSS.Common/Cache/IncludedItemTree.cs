﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace TAGBOSS.Common
{
  [Serializable]
  public class IncludedItemTree : SortedList<IncludedItemAddress, IncludedItemLeaf>
  {
  }
}
