﻿using System;

namespace TAGBOSS.Common.Model
{
  [Flags]
  public enum EItemFlags: ushort
  {
    None = 0,
    HasHistory = 1,
    IsInherited = 2,
    IsGenerated = 4,
    IsBlocked = 8
  }
}
