﻿using System;
using System.Collections.Generic;

namespace TAGBOSS.Common.Model
{
  public class TItemIncludeTree
  {

  }
}
