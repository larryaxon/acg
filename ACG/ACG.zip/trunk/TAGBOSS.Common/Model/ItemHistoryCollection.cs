﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TAGBOSS.Common.Model
{
  /// <summary>
  /// The Collection class for ItemHistory
  /// </summary>
  [SerializableAttribute]
  public class ItemHistoryCollection : DataClass<ItemHistory>
  {
    new public object Clone()
    {
      ItemHistoryCollection ih = new ItemHistoryCollection();
      return base.Clone<ItemHistoryCollection>(ih);
    }
  }
}
