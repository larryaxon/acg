﻿namespace ACG.Report {
    
    
    public partial class ACGDataSet {
    }
}
