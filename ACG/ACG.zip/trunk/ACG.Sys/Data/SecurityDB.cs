﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ACG.Sys.Data
{
  public class SecurityDB : ACG.Common.Data.SecurityDB
  {

  }
}
