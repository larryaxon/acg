﻿using CrystalDecisions.CrystalReports.Engine;
namespace ACG.DesktopClient.Reports
{
    public class ReportBase
    {
        public ReportDocument ReportDocument;
    }
}
