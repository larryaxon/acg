﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ACG.DesktopClient.Common
{
  public partial class frmMessage : Form
  {
    public frmMessage(string message)
    {
      InitializeComponent();
      txtMessage.Text = message;
    }

    private void cmdOK_Click(object sender, EventArgs e)
    {
      Form f = this;
      f.Close();
    }
  }
}
