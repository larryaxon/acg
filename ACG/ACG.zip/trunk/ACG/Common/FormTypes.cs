﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ACG.Common
{
  public enum FormItemTypes { String, Date, DateTime, Bool, Table, PickList}

}
