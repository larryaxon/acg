﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;


namespace ACG.Common.Data
{
  public class SearchDataSourceGrid : DataAccessBase
  {

  }
}
