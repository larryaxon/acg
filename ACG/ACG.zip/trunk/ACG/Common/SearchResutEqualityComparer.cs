﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ACG.Common
{
  [Serializable]
  public class SearchResutEqualityComparer : PickListEqualityComparer
  {

  }
}
